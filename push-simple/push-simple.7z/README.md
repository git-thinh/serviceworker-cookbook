# Push Simple

Simplest example of Web Push API usage. Send notifications to users even when your page is not open.

## Difficulty
Beginner

## Category
Web Push
